# (c) Copyright 2020 Hewlett Packard Enterprise Development LP
#
# @author alok ranjan
from tests.nimbleclientbase import log_to_file as log

'''AD_MembershipTestCase is not implemented due to external dependency '''

log("**** AD_MembershipTestCase is not implemented due to "
    "external dependency *****'")
