# (c) Copyright 2020 Hewlett Packard Enterprise Development LP
#
# @author alok ranjan
from tests.nimbleclientbase import SKIPTEST, log_to_file as log


'''AlarmsTestCase is not implemented due to external dependency '''


log("**** AlarmsTestCase is not implemented due to external dependency *****'")
